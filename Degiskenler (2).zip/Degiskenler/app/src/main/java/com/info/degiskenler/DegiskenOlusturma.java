package com.info.degiskenler;

/**
 * Created by kasimadalan on 7.02.2018.
 */

public class DegiskenOlusturma {


    public static void main(String args[]){

        String ogrencininAdi = "Mehmet" ;
        int ogrencininYasi = 17 ;
        float ogrencininBoyu = 1.78f ;
        double boyu = 1.86 ;
        char basHarf = 'M';

        System.out.println(ogrencininAdi);


        int urunId = 3416 ;
        String urunAdi = "Kol saati" ;
        int urunAdet = 100 ;
        double urunFiyat = 149.99;
        String urunTedarikci = "rolex" ;


        System.out.println(urunAdi);
        System.out.println(urunFiyat);

    }



}
