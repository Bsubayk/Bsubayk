package com.info.degiskenler;

/**
 * Created by kasimadalan on 7.02.2018.
 */

public class DegiskenKapsami {
    int sayi = 456 ;  //Global değişken

    public static void main(String args[]){

    }


    public void metod1(){
        String yazi = "Mehmet"; //Local
        sayi  = 6 + 78 ;

    }

    public void metod2(){
        sayi = 567 ;

    }

}

