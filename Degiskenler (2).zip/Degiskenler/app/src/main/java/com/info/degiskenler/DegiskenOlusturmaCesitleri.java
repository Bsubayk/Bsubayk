package com.info.degiskenler;

/**
 * Created by kasimadalan on 7.02.2018.
 */

public class DegiskenOlusturmaCesitleri {


    public static void main(String args[]){

        boolean kayitKontrol = false ;
        double en = 1.78 , boy = 4.56 ;
        double genislik,yukseklik;
        int sayi = 67 ;
        int numara ;

        numara = 45 ;

        genislik = 6.78 ;

        System.out.println(kayitKontrol);

        kayitKontrol = true ;

        System.out.println(kayitKontrol);


        int sayi1 = 78 ;
        int sayi2 = 67 ;
        int toplam ;

        toplam = sayi1 + sayi2 ; // toplam  = 78 + 67 ;

        System.out.println(toplam);

    }

}
