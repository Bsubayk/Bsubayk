package com.info.degiskenler;

/**
 * Created by kasimadalan on 7.02.2018.
 */

public class GenelKacisKarakterleri {


    public static void main(String args[]){

        String yazi = "Mehmet \"80\" notunu aldı." ;

        String dosyaYolu = "C:\\users\\masaüstü";

        String paragraf = "Merhaba\tNasılsın";

        String paragraf2 = "Merhaba,\nNasılsınız.\nKolay gelsin.";


        // Merhaba bu “android”
        //       eğitimi  java \ dili ile öğrenicez.

        String metin = "Merhaba bu \"android\"\n\teğitimi \\ java \\ dili ile öğrenicez.";


//        System.out.println(yazi);  //Bu önemli

        //System.out.println(dosyaYolu);
        System.out.println(paragraf);
        /*bu bir yorum satırıdır*/

        /*System.out.println(paragraf2);
        System.out.println(metin);*/




    }
}
